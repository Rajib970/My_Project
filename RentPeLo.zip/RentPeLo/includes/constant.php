<?php
 $host="localhost";
 $user="root";
 $passwd="rajib";
 $db="playbees_users";
 //Database connection
  $con=mysqli_connect($host,$user,$passwd,$db) or die("Connection failed");
?>