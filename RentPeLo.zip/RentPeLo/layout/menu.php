<nav class="navbar navbar-expand-lg navbar-dark bg-success fixed-top">
    <div class="container">
      <a class="navbar-brand" href="index.php">RentPeLo</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarResponsive">
        <ul class="navbar-nav ml-auto">
          <li class="nav-item active">
            <a class="nav-link" href="<?=$siteurl?>sites">
              <span class="sr-only"></span>
            </a>
          </li> <li class="nav-item" id="query">
            <a class="nav-link" href="tel:7074850985"> <i class='fa fa-phone' style='font-size:20px;color:red'></i> 91 7074850985 </a>
          </li>
        </ul>
      </div>
    </div>
  </nav>