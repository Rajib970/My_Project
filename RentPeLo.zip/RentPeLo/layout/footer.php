<html>
  <head>
  <!-- Bootstrap core JavaScript -->
  <script src="js/jquery.min.js"></script>
  <script src="js/bootstrap.bundle.min.js"></script>

  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">
 </head>
<body>
 <footer class="py-5 bg-dark">
    <div class="container">
      <p class="m-0 text-center text-white">This Page is Created by Rajib Shaw</p>
    </div>
    <!-- /.container -->
  </footer>
</body>
</html>